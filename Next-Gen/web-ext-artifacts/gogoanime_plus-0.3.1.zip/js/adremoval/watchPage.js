(function (){
	
	function cancelReq(req){

		return {cancel: true};
	}

	//Kill bidgear requests
	browser.webRequest.onBeforeRequest.addEventListener(
		cancelReq,
		{urls: ["*://*.bidgear.com/*"], types: ['image', 'script']},
		["blocking"]
		)
	
})();